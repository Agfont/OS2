//
// Created by ruben on 15/3/21.
//

#ifndef PRACTICA4_RATING_H
#define PRACTICA4_RATING_H

struct Rating {
    int customerId;
    int rating;
};

#endif //PRACTICA4_RATING_H
